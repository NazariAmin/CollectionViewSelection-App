//
//  IconCollectionViewCell.swift
//  CollectionViewDemo
//
//  Created by Nazari on 5/7/17.
//  Copyright © 2017 Puia. All rights reserved.
//

import UIKit

class IconCollectionViewCell: UICollectionViewCell {
    @IBOutlet var iconImageView: UIImageView!
    @IBOutlet var iconPriceLabel: UILabel!
}
