//
//  IconDataKit.h
//  IconDataKit
//
//  Created by Nazari on 5/7/17.
//  Copyright © 2017 Puia. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for IconDataKit.
FOUNDATION_EXPORT double IconDataKitVersionNumber;

//! Project version string for IconDataKit.
FOUNDATION_EXPORT const unsigned char IconDataKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IconDataKit/PublicHeader.h>


